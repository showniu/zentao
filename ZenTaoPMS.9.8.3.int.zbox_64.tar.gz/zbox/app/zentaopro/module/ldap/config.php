<?php
$config->ldap = new stdclass();
$config->ldap->set = new stdclass();
$config->ldap->set->requiredFields = 'host,port,baseDN,account,admin';

<?php
$lang->action->desc->repocreated  = '$date, created and reviewed by <strong>$actor</strong>: $extra.' . "\n";
$lang->action->label->repocreated = "Create and Review";

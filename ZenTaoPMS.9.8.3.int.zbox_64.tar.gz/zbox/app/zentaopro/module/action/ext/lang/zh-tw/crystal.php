<?php
$lang->action->objectTypes['report'] = '報表';

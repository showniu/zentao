<?php
$lang->action->objectTypes['report'] = 'Report';

<?php
$lang->action->objectTypes['effort'] = "日誌";
$lang->action->label->effort = '日誌|effort|view|effortID=%s';

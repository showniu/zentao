<?php
$lang->action->objectTypes['report'] = '报表';

<?php
$lang->action->desc->repocreated  = '$date, 由 <strong>$actor</strong> 評審創建：$extra。' . "\n";
$lang->action->label->repocreated = "創建評審";

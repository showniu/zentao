<?php
$lang->task->gantt                = new stdclass();
$lang->task->gantt->notice        = new stdclass();
$lang->task->gantt->notice->notSS = "After task \"%s\" is started, then this task can be started!";
$lang->task->gantt->notice->notFS = "After task \"%s\" is finished, then this task can be started!";
$lang->task->gantt->notice->notSF = "After task \"%s\" is started, then this task can be finished!";
$lang->task->gantt->notice->notFF = "After task \"%s\" is finished, then this task can be finished!";

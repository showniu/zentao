<?php
$lang->task->gantt                = new stdclass();
$lang->task->gantt->notice        = new stdclass();
$lang->task->gantt->notice->notSS = "任务：“%s”开始之后，该任务才能开始！";
$lang->task->gantt->notice->notFS = "任务：“%s”结束之后，该任务才能开始！";
$lang->task->gantt->notice->notSF = "任务：“%s”开始之后，该任务才能结束！";
$lang->task->gantt->notice->notFF = "任务：“%s”结束之后，该任务才能结束！";

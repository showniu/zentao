<?php
$lang->task->gantt                = new stdclass();
$lang->task->gantt->notice        = new stdclass();
$lang->task->gantt->notice->notSS = "任務：“%s”開始之後，該任務才能開始！";
$lang->task->gantt->notice->notFS = "任務：“%s”結束之後，該任務才能開始！";
$lang->task->gantt->notice->notSF = "任務：“%s”開始之後，該任務才能結束！";
$lang->task->gantt->notice->notFF = "任務：“%s”結束之後，該任務才能結束！";

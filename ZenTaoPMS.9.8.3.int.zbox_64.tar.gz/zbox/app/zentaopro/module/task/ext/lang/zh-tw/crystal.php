<?php
$lang->task->timeout = '超時';

<?php
$lang->task->importCase    = 'Import Task';
$lang->task->import        = 'Import Excel';
$lang->task->exportTemplet = 'Export template';
$lang->task->showImport    = 'Show the imported';

$lang->task->new = 'New';

$lang->task->num = 'The number of tasks';

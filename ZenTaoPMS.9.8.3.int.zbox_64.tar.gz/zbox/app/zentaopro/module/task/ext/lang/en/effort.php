<?php
$lang->task->recordEstimate = 'Effort';

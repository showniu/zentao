<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPm0nJ/pgaRFpH/pQtpiAYMwWcRrvSFO6aFiSrLKUoeEWjaIhofpx7pvZSOVAKErysbpi4Fsm
pKKzRPJcyTkediZEsPqhk2wrHNktbCCT+c8RQ65AJu8MCCMuDd8gKfOuFgU8jP5rY2q/YfrYVaJ/
QI6silqGM5NT0fYnwTqKwN7H6xZHP/TnsC4VQUUycvExzXrPQCDHp2Y+lsfT+cI+o0KRkkulcQvm
1GyFDJ1wiMTYda2z8nuApoXHRd6Qi309Nl9Eu8pkfKZo+tcUrgvuErbZzWoAgWzW4Kj+FXX305vk
yVXTNFjVJJveP3tP+lKM/4rY0srsaX1nPWK0cNteWAT3fi4AieEZ12gj7rUTOzqCQAG/yVjQtMF7
D66E34v7lP0iFo5tqBHaq7kKk+dciJTr0ecK0ZokAlK3wk+8Rxdt/RBEy0oAzSYKLqq29yBObTb+
UUb51F3XnPjVGowfFI7SZWVlOjT4X+g4vz/U91zLZhAzeDvniNpO1867tk8QxMAsmrnuOOi/zbM4
lHcuDVqC1+HnqJWXKw9/mB34qXw0Gpq2NTPYoEatK0Oo2jQsraETocLky9qgvuo6Z8J6I0lYiE/C
E50B+txxfTlmmbJtYusnyVoaOoO+/F9F7DpRrgajSZ8xcTGvvwh1eCS3LfFcsL4R9lIzgIOw5cI/
N/UiffVBnjsX1ZKutggLMLFQ7H9geu7D1Cte1Fhx4Jws/LdVFPRJq8D7QXG6DxwoROO4WdEyenuE
7DL6KhagS4d/mKrMavyi30u12HuKZ10c2gkxWyT9/RaHC5gi5yV1EsIttkfR4NClL4WX59lQ4biT
jc19rDrkuAJxBKHfckLpo1JBdt4I2cJXFIa/njbdBc5y5MkfqtXOzJRso2fFRV7HJuQ72JHAY7Nb
L0pWfdFGE/bbK9uW0gZBG0JISsP6gHCwpwAjaztiGkrrVzeurT1jT2TPkNc5Oy05AkAx7AMRCoty
xCL6hrGcFNSJQ37RpFEN9l5cmcxnQElXF/sv+IP5HCAWPtPhMUp9yAtQjMi9oH9YFeaLnY1UR+k6
QFoiELrnVp+IbL4B3bcLUiwLEEqTyOoBk5WmG/9KkX0w6WYTSu5RdKXn5t526JxtYbXHl50Ly0EK
Ua7lrpTSarKbKFIC9rwadEBjP6M+qZGERemdtjsFffvIzeHbm6tvL01GLW4lKnZpLoW8ypRS3KwR
jApoUVJVwD8Yt/yxK54RjKCvFne7f0BmWGkcaQ9iUI66BCjkbquqnyHVyBEiE089MPZDPxAJh0qZ
V6iQ2Er3smLcM7Y66UmKRz5KNYMOjwaC7qiPRpEfI92E+VwD7JrP5SCRzVQn0rFgds0LqPdInAs1
mvuY+iWevTkhnbcN1UtbziJ7dRxKavpibFMyOmUzVjHCRCDX9lKUl3CtXFhlSuiaCvqngAF7wOGA
9nWe/7EdmwR5RjJxIcnKOQzQtYdrLaLnmsuklCVnqnG2Me4zrLXe+R6fy4rZ5jQrk/xVZXB/CbD7
lA5d/ehvSuzEaELDqpKFE1y/oCokspdel48EUQQmXmWGHG5/cILL+3HOtjRtTWcOh3EQW8nSHg2K
f3kTo6EwcVFuEY8d2FhpTBA36EgygGPXXojbMNoFMax2HoX+I/g11RH+kmZDB0P/VCmsxYMiXqbE
vkdCggTq5kcAoq2DGqoYd+AX2tIxs5F5o8mg7/gEQf3pYPerJp82gBGRQOBfuMWupX1sGkQOg9BC
DYtPPL4EqL3ogqKJLfnOvJxiIaswGkgD52cd80BBvp/Q9t3Ad6Ef1qvZxwkEB3gNsHjnAZ5l6K7x
DQBaCRLV5v0cNzcCR0VgWJfcC20vHS2+n6zXw53Zk+JanaIa3IRhrFpzG7LqRgnXbQGEMymcWrQ7
XRZLaLfctn3tXv4JSQR838rxpKrMzRqJqaei4C9wjBGI6p0CdYNCyvPKZaegAy1jrcxmttQ+U93p
I6KZf87zJaoCN+4zoFkrFjBWkYkqMzFXESrrm9gwOsTgnKDNJHfvU/wmEuumg/CrfBtCbCMy12oX
+GA0/xYXVqHqa1vDhPIqOlUtCRJgazFYdYTw1w8wSKXaCwP2QQHOo4e17M0Zd33G7t1Jw60uTKD8
vSqhPOkzQ7+UkNGuHoQa4vrozUgUCV/uXGe9t1nTsR+1VvEFLhRFdWug5uXmmixILqENNXppmMqS
VWHLQma94ALDxYGz+YVLGUNnai31SbHJ8U5RL1a5BFJTas7yGXxUvyw+aYRiKgDu9fR4Cetg5KJh
VelMGqWO1r7UEPY+fPcrhRds6fpERschqx6MiwOK4Amz3FPIoggZgVZ9vultuFiWdI+ZKueBqKBt
/rW0sY1Gcds9B5yNNX6NUTfhbRZrNODHNoEJk7jtjbhINjcvPo0srhku1rYTYPd0g1x5/lMjoU+1
rYYtobX1wxYi9R+H77Q6agqFYYSeWm7uMeQWLK2fLHHMHLZJsrZjUtuX5Mwh07RKbdaEUu+kzO+u
BsKiyspT/XcdQ8rAn7YXr9nx6ArkGET8tpzbVjGADd+o2qfjsKXvf0vtFjIqQinOVhS2U/JrWO+9
ROap5wHfxkv7UrvbsuPP9FCa77U2yHnbSuqs2+whWfV+KmeshXpq5DqB9xsA+D1zqvkELJyQ8DeH
TfncvOxvPeC6Be+SvtjwAaVgMM1chVBJNMCQczCivq9XUvCvhbuXriKFvJ1r85Ic8Yb8vYjDst2m
V04ZBDWOT0bNEood3jcqhfbtFPCL9bhHDvpkfWYisd7KXeKAeCOmy3+GoJBB+hP+Dxy/1xCDFxFG
mK0W2XGNdW/u6QhWQIOcacELm/hQug375dHKENj3NITHym7pGH2eyYfgFQ/JoZZ9P2popDyrmgWS
1102pkzTm2dEBxl9jqj0imvoow1v/b0oeDr/yFktuqZELhA0e2c3jqVjZ5zi05LDJg6jfncrbB8B
gisJRt5p6z9hnGzwqymmasFEg72+ynBEFNpyk7nKFKGOrHFJsxDiJo8gN8gexVInb6w+gAWea/au
NBfmakCccz18kEOVucvWbJ4Cgc3As5b6vgb0GfRKrkUVHylrAIaoes60u1X1Vo5BpqYOqPLUCO4I
xGCXCOjKZtiblGXV99EAbAE0SCqieJrIIdbw5PtZYySWEL41aJHgalFIbTczVoQlwYsYAuv6JQpM
LF/k0mc6mrz2vei8KRoHdLOcvMQpso91Yvu5Hz6y8WoR6huvn54cztuu0n3CqSp/MT6aLUWn8xy3
1S6sHYEZkaG0Do51ZikZwG0bmLLja9SpyZqHTbzA6YamFxH1LplFx/4ahh4D+9Mxtei7QQktPwl+
XClLJ9SLr3bvX0ek5wdNep5ISfDvXbGKYnKO0gxHYVS3hZJHVx2XHyBs51p/rkJuim7HqGvULCeO
XGD2HvL7AvmoQrBpEOgw7OS035NaKqU/aOBebUfRUdqRzJ8ChsM730rG21rpcaBqAocV02/TVxXC
PUgyK9ribmm2VOuezrW6TCGMHfV8rtXPlrxOxQHgGa6iB1x0X5YyB8UoNDBzrbyVlIWpJdJvmwZe
LIT3EIRGYyrFupqca0ccDYH3aEK7WI9joDPO9VXhUxsTkTe6oe6zyegPQHObLYzTvsSi6H43Pkt0
5OFxRGBNtL2iYLfEDITTaveDbhIXdHOEPaGu5nICNqu5sf0mh8ewpUTLooCCvB2yfUZGG9qakF4m
0D9SZYVCtAablpZE8aK=
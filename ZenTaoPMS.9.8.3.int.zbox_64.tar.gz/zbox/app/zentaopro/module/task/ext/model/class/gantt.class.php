<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPwrQJSgg3xRj1vBOwRZKVyeQ+K07A1+8iJ1uYZ0TEK2FxD/VpVftgZYueQsGC3fX7t013syo
EHBcz+6PBZ5DVmN1nIueDOgT1g29ULGxkAGZyqqwnf9HYA8QiGKh396oaMY9udRcX61B2xO/sDtk
S1IMkhioFi49C39LkfM2TY/C+6vBGVgiGvTQ4uLOtNqPxjrwZqYS+mkqM00fpCk/ttR4aHZat8Ar
K3Z5h7u6HYAXScJ9o4t7QPIjycHSCGh66fVbZufc/sbmQkJZ79wh1YLguVqqWEz+Sxo7+i4tyelu
A6YUJ2cBkZ8NCalRsPuIn8gBTQMk6q2fTEH4h3tR0eEpZ2PJfbGqEEkbD7/AQFvhlb1ryPcToys+
OySqOKv7lP0iFo5tqBHaqEYJLtLM+MrOnqr3T3nMfW8g38UNUHJKfuYjK9OmdeeWGlBKFUPkdyOW
WKeSGJxgy5GSiumqI2NKhqzCmztAVsZrYYaa7g9oXbm3zx3XOgFR3Z/ELve+k7MhWEnq+4khpuO5
F/HesC/9vFYX5uIb5VjG0aRfdwUx/Wp8PyZPG39xR6l0RQDbGM+8svZtdusd19zAzpW3Nu6AOiCg
1YBgGAJyls3sNzd8jmwQIJ9oBPoCmEQuNjqHtxR6UyRMDny2OstKjz9pAixDOkOnje4DDnS4XgOR
GSF2caxbCfBAfEpXbZieCe+h0wWjSsWMbN13vFcZ9fnBI1z9xKr1rgNAeki4X2QO4BJpFueryV0L
duISvJ9lunl/UM0/quEpuMCd6iWFYOHTSQ8jv7WGbXTXdyaVnBXLggT+X7VmffOIAvObllGXaA4u
7QhqergWUpgKnOCqcwlozdtTphsoN98dLwLgXzEQ5+q3szWTZthsIf0NyV74JA7SplnOSjVV5EqV
MoN/zmKUiLuGgIBcxbKvVBKhsGh2eKgEsmhV96SJH57jbIjrOvqgUB1GU1+zmnPjNX3OTjTPq5IS
sf5aBi1e2gBuHXhZiN0JZOI3nyBU8wTYCvdZk+8UJCbU+fT3TcN62Gm0IUMhKoF/DEbM2o3I3C+S
Ngqgr/F+k/SiWAoFBQTsB0yc6XNSyQKx4hnID7sr4rVyxJHSVa7XpApaBAyNwkZhI/14uo66TgoA
tS0Qx/4OV4v6n2mqj6ky7ZBh1bQv63ZwrKOeOXJSw4PLIwhVlblDQBABS6YZm9v6854rDFn4JW0J
tGmBIFjLTAL673U2CpY8WVORkGqDZh912+XhvK4V1XFz7vdUtULTYnaI+B9X1+EcXYXBnUOjoBh2
rjpi+YW0+Oi7bCAQNZFzzSA0UmHKqhxYmHbX5uYO8uF5AY+6sW4qV95BR0WveRKOdt7FV3hE2tRD
qhMWIcH596eFatAWcFlxHK0ZUGyfJjhqdlrv5pM6pKEoYmP46dWK8jMP4gwnoZTRXFjQ2ll2dys4
Szz5GBcQLYaBvCX5WNXnVlTGcmC9/nkf8tMb7kDAuBP+S3y+0lkideG03ZG03jlQrUSg1hb8xnEd
+OUkcqo0sYvCpaqlGuSWf+7RkXC/y64j2OsNnwKGh9MiK+oudVc9tGNeYFoLltRVoI0p8Ezw64hI
nRsNHVvikcrzfWThbjbdPrqxKxGWfVLhUEGXJ2vnQp5f3KjPy3ErRvF2VUCgG1q7sEi9S2B/rGZD
yhI6vCx4tvXRDz6kKcs73Ctg8ONd8u0UdvAsqwAmgURLORkEvGA9sBxmcCgJ1haz5U+mG8IB+SbT
ItQA9l47PN74YVOCBF2V6gTxQQHeoMX+d5ZT45uT6/Ub3PJHr5Zl17Rw+hkCD69jL6ZyXLISpwRw
kMpHWLfD0FBBiGMX/q+/kup+1fDbqJA0m0i8RoUhYWCs5cbRf84R9AoSaj08smPxjeDWStmkz1Nx
9BiJkanj934j7Q5lO5zZdue7dOecHrEvaFF3uRUg2X3vFWyqGtipi6tlyjGhEYZTn5FWJGYF0zLf
OmT4AqCT6VvpmKsiQt1L5taWFbma7iZJux5Ym3gfoAyGAXhUE5IOfNhu6x0fptg2E5XcXGWSwNZX
dJlfdV9ZkBzIlU79fi3lw9xE7CWj7fjjIn5Yjlj1rJP6iBBhFY7ubNh2vatRdn66PZydgn4oLEwY
EffWOFYNWYW4qNvJl68MZTWIY50s0f3pH/zfJ/yppIrNLvXNhqVvMUeoxhjmfbRoY4NkM1O7MTAE
8T+RxsByC+XWWuJHGtwno2yiucsvtDAIw7RK/CPq1taobGIQLnhb5/N8Jh7MqG7x2Rtl0cULI59O
zO3QLELYQAR8D2rTNYfSuIdkYDp1hGvOFZfPn5cEpR0YTWpN7E/qVryE0hPl70cTU0iFY0kTR9o3
Z1O9daKfGYlDFW4Jkjw3qJDLedQiTRXw+0kCEpEbfLsSE1gmqcttZgGjs4VjRHG8rvMMtUcXpnrd
u0zi0xamAvfmIF0Sk4DzsjuH3TFpI7LaDH8SqtM1z7e89cWg+xp/U4xS90X2WGLZMweb6AC31Qbl
urXDWwDYCkkmITKqP0mjlfG6MycCrnLqZ5DgY1WRn6mT76eO0C0/7LbUPaYetSupW9jJGnrrvdIl
WjfWnkEmgfuhI2Hd1DXT+tmbSh1bHkgAt0o3FGU80lvJIr1s6tm0I2g+IgAIGOParB9O9HgHYg5W
flKquMoGbPhjx8AcEdFZBe38HXrRkYF6iI+mAS8omT06B+qOnDwpZnWQg3coXd4Fw2DDp8rW7YYM
GrHdo5Tu2zxHMhzf0YoRNM7SODvCClCxu5t9PUJY56pc7Jj6tGyN/tTX6fTdbCdbHZGXS9rjFk05
p64a20tJFJ9LgjK6BGRiA8GsMQvJpErHjqEdPGSZ9rt/bpwVm5h7EGLC9yqOMMciRHZCEXYLohK8
7kXUhdK2TYBNLTmMynj82oxz66HLq/fNYTzEzPbEQq0KJ0TNQTUCSs2FKAP5+ljJ5H5fASAzrwEx
8kqZrWESdkZSDczyTsHTObW2+J0zhw2Ff9RFSjRSjS46Qmt+NxXKfq85ADq46/209DS97ECLBNgR
85eopxHCIV8FDdeqB2+InM1sgVtjQXBRfecIifIuA0Q8RPhYRjX7TnUvi9EejkIyLWOZjmVYJs/V
W1GM2PMLxUjl9XAzE3bi+mCGnbzvgoN0/O/dcxM26oJsaH8bn8DFYWBEf80SX9dv3Dia8jzOI3S7
BFexPSBYQ4zN53kt7y3fCbhgU5nx/UJ8YSr2pKLTApTJYdCVNdxOobyhjbX6mV1Sup2utSNCDffh
A995w1OQWGYfpMXHPPu3LkI4DPql2xXUAZ7l0seVS/MfM625PbZzAkuuyfnqp9IcIMGH5fLaos0V
4nrlRoJCzai8hiGlmg/b+vuk9S+qc0FUtmgki+9hkwuTYRqaxZbx0pSCLllEYJGLbOwlPEds60/E
7Xi2OtbSvb4cpcFv11IqV/jegxG2ZIvrwgXY2uNGDJY6HXRfEKYm117dDpE7wJdX4oY8bmaCMFSw
NDPcpApFmH6PdfRMfOILtbTW9qP73gnr/Poske/ZJvLgAm7hYpub0RHs/pvuNEIWZ9P82a2OdHC9
Hvf+D7XirZ+hxPSKYRovKSMDV6YcRWjx02HIgBvP5OJL6JdR/58VKyC0/rvyRnDzzJKAim89Uh/M
b5guKFXBRe04tgVaQ3Fm9gyiHIPg4vXtFtf8fEWXTu0O+oeeqaiC5d1ch5I8edOT2T66+FrcYK11
sxNa6Djb+xeMyGw+QVjZPfFFvBDOqEaLLKHskWIDFQzPzovrprqkne8xqHcAjwdotVKGGPuD4xBh
3zK1fRPDiLy5KVii054zuWw6ckKp1aA1hhNsOCiJLxawM2b85mVwj9LDdsNWq/a7Rr6S5YXLHdUa
zuD89Yhm4TWpBIGY11t/WN0804Sio15mytcXTAebgs+GGRANsmg7Ev6y3BmfNTr8SaakuiWe+T6y
vAMHqN4pMNS6hE1L2+TsfARgv/6qQstjU5QW6UUer7X7+dKM3kpVEUdFsZK1CZyMtc5GaQI0m8PH
v/rPdTaXH8FmIPPpIl/TFwmVqkRNv2EYmaiB55zGN4/N5rDmjv4Gs+2vtqU4VCdcfC+lk4hzFsp0
UDwzarn4MvJuJiQZEwAhxZHsD9CgmQOPUZRMBAnvSztoDD4Q7o3ALSWdI4azDC6narGVV5I4fTb3
jBUB85tXejNTUsJ6louZqJ53py0FVVGnDqqhhF/VS7loVQJikBOh2LKTJ//wAwUmcanoTqEYja5L
W8hauYYBifckSKw6vXDGHsOKGKvbyJDLtDPYQhcev2Bi0pAhUGTgw1oTo1yBlfCLXumfXp1e+j/9
dBo0JoTdGpHeceDmp8XOQZJOtvs8WQnHpLJL/qPRu2SIVNsFNcyoARndVoDo65JUVd0HosxyZcFz
iMLwiPXmvK05gKsBqhaGqcdEu7W+eDyMfIwTdWMEXLuqI3GLQAlQGgySJk7aS8OYKhhBZxS9mgZ+
FJHSomGlRc+19jz3Yg3I/SUecC0ZffFptEs47lPvs36jDX5uQNsXX7Td8CaF6nvoEj3hMr4VAPiG
2yipjIh4M4sJuKyhFH17OQOgAxQjBfo65fHbj4IMVJLGSu3efeB5yikgfu3p2GZqdaccTdHPuZIm
yAwhYaEGXxtSnjjtbEtJcf0ALiSDS5EHJt01/f3QUVBdgsFFlRHTE93jD0z9IzsuNw1wV4624zUb
VY1H8G==
<?php
$lang->story->importCase    = '導入需求';
$lang->story->import        = '導入';
$lang->story->exportTemplet = '導出模板';
$lang->story->showImport    = '顯示導入內容';

$lang->story->new = '新增';

$lang->story->num = '需求記錄數：';

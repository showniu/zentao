<?php
$lang->story->importCase    = 'Import Story';
$lang->story->import        = 'Import';
$lang->story->exportTemplet = 'Export template';
$lang->story->showImport    = 'Show the imported';

$lang->story->new    = 'New';

$lang->story->num = 'The number of stories';

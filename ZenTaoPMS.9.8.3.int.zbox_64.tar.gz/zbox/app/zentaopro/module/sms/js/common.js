$(function(){$('#featurebar .nav #smsTab').addClass('active')})

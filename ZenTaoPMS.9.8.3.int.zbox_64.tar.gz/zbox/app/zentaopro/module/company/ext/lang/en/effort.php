<?php
if(!isset($lang->company->effort))$lang->company->effort = new stdclass();
$lang->company->effort->common        = 'Effort';
$lang->company->effort->selectDate    = 'Date';
$lang->company->effort->projectSelect = $lang->projectCommon;
$lang->company->effort->productSelect = $lang->productCommon;
$lang->company->effort->userSelect    = 'User';
$lang->company->effort->timeStat      = 'Total Man-Hour consumed on this page is %01.1f hours';
$lang->company->effort->view          = 'View';

$lang->company->companyEffort = 'Company Effort';

$lang->company->dept           = 'Dept';
$lang->company->beginDate      = 'Begin';
$lang->company->endDate        = 'End';

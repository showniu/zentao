<?php
/**
 * The view file of company module of ZenTaoPMS.
 *
 * @copyright   Copyright 2009-2012 青岛易软天创网络科技有限公司 (QingDao Nature Easy Soft Network Technology Co,LTD www.cnezsoft.com)
 * @license     business(商业软件) 
 * @author      Yangyang Shi <shiyangyang@cnezsoft.com>
 * @package     company 
 * @version     $Id$
 * @link        http://www.zentao.net
 */
?>
<?php
if($iframe == 'yes')
{
    $type = 'effort';
    die(include './showdata.html.php');
}
?>
<?php include '../../../common/view/header.html.php';?>
<?php include '../../../common/view/datepicker.html.php';?>
<?php include '../../../common/view/datatable.html.php';?>
<div id='featurebar'>
  <ul class='nav'>
  <?php 
  echo '<li id="calendarTab" class="active">' . html::a(inlink('calendar'), $lang->company->calendar)    . '</li>';
  echo '<li id="today">'    . html::a(inlink('effort', "date=today"),     $lang->effort->todayEfforts)     . '</li>';
  echo '<li id="yesterday">'. html::a(inlink('effort', "date=yesterday"), $lang->effort->yesterdayEfforts) . '</li>';
  echo '<li id="thisweek">' . html::a(inlink('effort', "date=thisweek"),  $lang->effort->thisWeekEfforts)  . '</li>';
  echo '<li id="lastweek">' . html::a(inlink('effort', "date=lastweek"),  $lang->effort->lastWeekEfforts)  . '</li>';
  echo '<li id="thismonth">'. html::a(inlink('effort', "date=thismonth"), $lang->effort->thisMonthEfforts) . '</li>';
  echo '<li id="lastmonth">'. html::a(inlink('effort', "date=lastmonth"), $lang->effort->lastMonthEfforts) . '</li>';
  echo '<li id="all">'      . html::a(inlink('effort', "date=all"),       $lang->effort->allDaysEfforts)   . '</li>';
  ?>
  </ul>
  <div class='actions'><?php common::printIcon('effort', 'export', "account=$account&orderBy=date_asc", '', 'button', '', '', 'export');?></div>
</div>
<div class='side'>
  <a class='side-handle' data-id='companyTree'><i class='icon-caret-left'></i></a>
  <form method='post' class='form-condensed' target='hiddenwin' action='<?php echo $this->createLink('company', 'calendar');?>'>
    <div class='panel panel-sm'>
      <div class='panel-heading'><strong><?php echo $lang->company->effortCalendar;?></strong></div>
      <div class='panel-body'>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->dept;?></span>
            <?php echo html::select('dept', $mainDepts, $parent, "class='form-control chosen' onchange='loadDeptUsers(this.value)'");?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->user;?></span>
            <span id='userBox'><?php echo html::select('user', $users, $account, 'class="form-control chosen"');?></span>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->beginDate;?></span>
            <?php echo html::input('begin', $begin, 'class="form-control form-date"');?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->endDate;?></span>
            <?php echo html::input('end', $end, 'class="form-control form-date"');?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->product;?></span>
            <?php echo html::select('product', $products, $product, 'class="form-control chosen" onchange="loadProductProjects(this.value)"');?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->project;?></span>
            <span id='projectIdBox'><?php echo html::select('project', $projects, $project, 'class="form-control chosen"');?></span>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <label class="checkbox-inline">
              <input type="checkbox" name="showAll" value="1" id="showAll" <?php echo $showAll ? 'checked' : ''?>>
              <?php echo $lang->company->showAll?>
            </label>
          </div>
        </div>
        <div class='form-group'><?php echo html::submitButton($lang->company->effort->view);?></div>
      </div>
    </div>
  </form>
</div>
<div class="main">
  <div id='showdata' data-url='<?php echo $this->createLink('company', 'calendar', "dept=$parent&begin=" . strtotime($begin) . "&end=" . strtotime($end) . "&product=$product&project=$project&user=$account&showAll=$showAll&iframe=yes")?>'>
    <div style='background: #f1f1f1; padding: 40px;' class='text-center'><i class='icon-spinner icon-spin' style='font-size: 28px'></i></div>
  </div>
</div>
<?php include '../../../common/view/footer.html.php';?>

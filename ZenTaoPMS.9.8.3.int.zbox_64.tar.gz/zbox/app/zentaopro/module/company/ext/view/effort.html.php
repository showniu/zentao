<?php
/**
 * The control file of company module of ZenTaoPMS.
 *
 * @copyright   Copyright 2009-2012 青岛易软天创网络科技有限公司 (QingDao Nature Easy Soft Network Technology Co,LTD www.cnezsoft.com)
 * @license     business(商业软件) 
 * @author      Yangyang Shi <shiyangyang@cnezsoft.com>
 * @package     company 
 * @version     $Id$
 * @link        http://www.zentao.net
 */
?>
<?php include '../../../common/view/header.html.php';?>
<?php include '../../../common/view/datepicker.html.php';?>
<?php include '../../../common/view/datatable.fix.html.php';?>
<div id='featurebar'>
  <ul class='nav'>
    <?php 
    echo '<li id="today">'    . html::a(inlink('effort', "date=today"),     $lang->effort->todayEfforts)     . '</li>';
    echo '<li id="yesterday">'. html::a(inlink('effort', "date=yesterday"), $lang->effort->yesterdayEfforts) . '</li>';
    echo '<li id="thisweek">' . html::a(inlink('effort', "date=thisweek"),  $lang->effort->thisWeekEfforts)  . '</li>';
    echo '<li id="lastweek">' . html::a(inlink('effort', "date=lastweek"),  $lang->effort->lastWeekEfforts)  . '</li>';
    echo '<li id="thismonth">'. html::a(inlink('effort', "date=thismonth"), $lang->effort->thisMonthEfforts) . '</li>';
    echo '<li id="lastmonth">'. html::a(inlink('effort', "date=lastmonth"), $lang->effort->lastMonthEfforts) . '</li>';
    echo '<li id="all">'      . html::a(inlink('effort', "date=all"),       $lang->effort->allDaysEfforts)   . '</li>';
    ?>
  </ul>
  <div class='actions'><?php common::printIcon('effort', 'export', "account=$account&orderBy=date_asc", '', 'button', '', '', 'export');?></div>
</div>
<div class='side'>
  <a class='side-handle' data-id='companyTree'><i class='icon-caret-left'></i></a>
  <form method='post' class='form-condensed' action='<?php echo $this->createLink('company', 'effort', "date=custom&orderBy=$orderBy")?>'>
    <div class='panel panel-sm'>
      <div class='panel-heading'><strong><?php echo $lang->company->effort->common;?></strong></div>
      <div class='panel-body'>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->dept;?></span>
            <?php echo html::select('dept', $mainDepts, $dept, "class='form-control chosen' onchange='loadDeptUsers(this.value)'");?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->beginDate;?></span>
            <?php echo html::input('begin', $date == 'all' ? '' : $begin, 'class="form-control form-date"');?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->endDate;?></span>
            <?php echo html::input('end', $date == 'all' ? '' : $end, 'class="form-control form-date"');?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->product;?></span>
            <?php echo html::select('product', $products, $product, 'class="form-control chosen" onchange="loadProductProjects(this.value)"');?>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->project;?></span>
            <span id='projectIdBox'><?php echo html::select('project', $projects, $project, 'class="form-control chosen"');?></span>
          </div>
        </div>
        <div class='form-group'>
          <div class='input-group'>
            <span class='input-group-addon'><?php echo $lang->company->user;?></span>
            <span id='userBox'><?php echo html::select('user', $users, $account, 'class="form-control chosen"');?></span>
          </div>
        </div>
        <div class='form-group'><?php echo html::submitButton($lang->company->effort->view);?></div>
      </div>
    </div>
  </form>
</div>
<div class="main">
  <?php
  $datatableId  = $this->moduleName . ucfirst($this->methodName);
  $useDatatable = (isset($this->config->datatable->$datatableId->mode) and $this->config->datatable->$datatableId->mode == 'datatable');
  $vars         = "date=$date&orderBy=%s&recTotal=$pager->recTotal&recPerPage=$pager->recPerPage";
  
  if($useDatatable) include '../../../common/view/datatable.html.php';
  $customFields = $this->datatable->getSetting('company');
  $widths       = $this->datatable->setFixedFieldWidth($customFields);
  $columns      = 0;
  ?>
  <form method='post' id='effortForm' action='<?php echo $this->createLink('effort', 'batchEdit', "from=browse&account=" . ($account == 'all' ? '' : $account))?>' <?php if($useDatatable) echo "style='overflow:hidden'"?>>
    <table class='table table-condensed table-hover table-striped tablesorter table-fixed <?php if($useDatatable) echo 'datatable';?>' id='effortList' data-checkable='true' data-fixed-left-width='<?php echo $widths['leftWidth']?>' data-fixed-right-width='<?php echo $widths['rightWidth']?>' data-custom-menu='true' data-checkbox-name='effortIDList[]'>
      <thead>
        <tr>
          <?php
          foreach($customFields as $field)
          {
              if($field->show)
              {
                  $this->datatable->printHead($field, $orderBy, $vars);
                  $columns++;
              }
          }
          ?>
        </tr>
      </thead>
      <?php $times = 0?>
      <?php if($efforts):?>
      <tbody>
        <?php foreach($efforts as $effort):?>
        <tr class='text-center' data-id='<?php echo $effort->id;?>'>
          <?php
          $mode = $useDatatable ? 'datatable' : 'table';
          foreach($customFields as $field) $this->effort->printCell($field, $effort, $mode);
          ?>
        </tr>
        <?php $times += $effort->consumed;?>
        <?php endforeach;?>
      </tbody>
      <?php endif;?>
      <tfoot>
        <tr>
          <td colspan='<?php echo $columns;?>'>
            <div class='table-actions clearfix'>
              <?php
              if($efforts)
              {
                  echo html::selectButton();
                  if(common::hasPriv('effort', 'batchEdit')) echo html::submitButton($lang->effort->batchEdit);
              }
              if($times) printf('<div class="text">' . $lang->company->effort->timeStat . '</div>', $times);
              ?>
            </div>
            <?php $pager->show();?>
          </td>
        </tr>
      </tfoot>
    </table>
  </form>
</div>
<script>
$(function()
{
    $('#<?php echo $date;?>').addClass('active');
    <?php if((int)$date != 0):?>
    $('#date').css("font-weight", "bold");
    <?php endif;?>
})
</script>
<?php include '../../../common/view/footer.html.php';?>

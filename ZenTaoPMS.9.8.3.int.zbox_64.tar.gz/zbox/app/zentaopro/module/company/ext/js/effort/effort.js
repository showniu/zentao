function loadProductProjects(productID)
{
    link = createLink('product', 'ajaxGetProjects', 'productID=' + productID + '&projectID=' + $('#projectIdBox #project').val());
    $('#projectIdBox').load(link, function(){$(this).find('select').chosen(defaultChosenOptions)});
}
function loadDeptUsers(deptID)
{
    link = createLink('dept', 'ajaxGetUsers', 'dept=' + deptID + '&user=' + $('#userBox #user').val());
    $('#userBox').load(link, function(){$(this).find('select').chosen(defaultChosenOptions)});
}
function loadProjectRelated(){}

$(function()
{
    var dateVal = $('#featurebar ul.nav li #date').val();
    $('#featurebar ul.nav li #date').focus(function(){$(this).val('').datetimepicker('update');}).blur(function(){$(this).val(dateVal)});
    setTimeout(function(){fixedTfootAction('#effortForm')}, 100);
    setTimeout(function(){fixedTheadOfList('#effortList')}, 100);
    if($('#effortList thead th.w-work').width() < 150) $('#effortList thead th.w-work').width(150);
});

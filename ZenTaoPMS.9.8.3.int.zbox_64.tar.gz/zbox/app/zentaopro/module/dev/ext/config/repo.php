<?php
$config->dev->group['repo']        = 'repo';
$config->dev->group['repofiles']   = 'repo';
$config->dev->group['repohistory'] = 'repo';

$config->dev->tableMap['repofiles']   = 'repo';
$config->dev->tableMap['repohistory'] = 'repo';

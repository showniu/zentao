<?php
$config->dev->tableMap['searchindex'] = 'search';

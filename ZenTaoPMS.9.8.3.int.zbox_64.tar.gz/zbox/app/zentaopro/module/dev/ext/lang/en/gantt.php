<?php
$lang->dev->tableList['relationoftasks'] = 'Relation of tasks';

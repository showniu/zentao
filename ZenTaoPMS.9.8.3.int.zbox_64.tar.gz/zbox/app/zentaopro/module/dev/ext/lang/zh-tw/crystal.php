<?php
$lang->dev->groupList['report'] = '統計';

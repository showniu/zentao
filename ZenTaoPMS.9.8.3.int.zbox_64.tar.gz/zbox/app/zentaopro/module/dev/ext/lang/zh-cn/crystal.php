<?php
$lang->dev->groupList['report'] = '统计';

<?php
$lang->dev->groupList['report'] = 'Report';

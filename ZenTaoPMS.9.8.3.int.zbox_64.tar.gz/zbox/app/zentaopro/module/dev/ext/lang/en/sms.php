<?php
$lang->dev->tableList['sms'] = 'SMS';

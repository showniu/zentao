<?php
$lang->dev->tableList['repo']        = '代码';
$lang->dev->tableList['repohistory'] = '版本历史';
$lang->dev->tableList['repofiles']   = '代码文件';

$lang->dev->groupList['repo'] = '代码';

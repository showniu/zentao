<?php
$lang->admin->menu->buildIndex = array('link' => 'Build Home|search|buildindex|');

$lang->searchObjects['all'] = 'All';

$lang->searchTips = '';
$lang->searchAB   = 'Search';

<?php
$lang->report->menu->staff = array('link' => '組織|report|workload', 'alias' => 'worksummary');
$lang->report->menu->test  = array('link' => '測試|report|bugcreate', 'alias' => 'bugassign,testcase,build,casesrun,storylinkedbug');

$lang->report->methodOrder[16] = 'testcase';
$lang->report->methodOrder[17] = 'build';
$lang->report->methodOrder[21] = 'workSummary';

<?php
$lang->report->menu->custom = array('link' => 'Custom|report|browsereport', 'alias' => 'custom');
$lang->report->menu->create = array('link' => 'Add Report|report|custom', 'alias' => 'custom', 'float' => 'right');

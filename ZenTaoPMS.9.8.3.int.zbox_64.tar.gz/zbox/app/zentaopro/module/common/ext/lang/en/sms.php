<?php
$lang->admin->menu->message['subModule'] .= ',sms';

$lang->sms       = new stdclass();
$lang->sms->menu = $lang->admin->menu;

$lang->menugroup->sms = 'admin';

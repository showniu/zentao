<?php
if(isset($lang->project->menu->task['alias'])) $lang->project->menu->task['alias'] .= ',gantt,maintainrelation,relation';

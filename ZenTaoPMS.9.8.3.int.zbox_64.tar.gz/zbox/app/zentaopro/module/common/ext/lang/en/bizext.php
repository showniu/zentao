<?php
$lang->proVersion   = "";
$lang->donate       = '';
$lang->try          = ' Trial';
$lang->proName      = 'Pro';
$lang->expireDate   = "Expiration: %s";
$lang->forever      = "Permanent";
$lang->unlimited    = "Unlimited";
$lang->licensedUser = "User Licensed: %s";

$lang->noticeLimited = "<div style='float:left;color:red' id='userLimited'>The number of pro users has exceeded that of the licensed. Please contact Renee at Renee@cnezsoft.com, or delete users.</div>"; 

$lang->admin->menu->license = 'License|admin|license';

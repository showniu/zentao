<?php
$lang->required = '必填';

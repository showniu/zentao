<?php
$lang->proVersion   = "";
$lang->donate       = '';
$lang->try          = ' 试用';
$lang->proName      = '专业版';
$lang->expireDate   = "到期时间：%s";
$lang->forever      = "永久授权";
$lang->unlimited    = "不限人数";
$lang->licensedUser = "授权人数：%s";

$lang->noticeLimited = "<div style='float:left;color:red' id='userLimited'>已经超出专业版授权人数限制。请联系：4006-8899-23，或者删除用户。</div>"; 

$lang->admin->menu->license = '授权信息|admin|license';

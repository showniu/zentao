<?php
$lang->exportFileTypeList['mht'] = 'mht';
unset($lang->exportFileTypeList['html']);

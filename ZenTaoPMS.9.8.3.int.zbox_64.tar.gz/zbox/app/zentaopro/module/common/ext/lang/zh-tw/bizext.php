<?php
$lang->proVersion   = "";
$lang->donate       = '';
$lang->try          = ' 試用';
$lang->proName      = '專業版';
$lang->expireDate   = "到期時間：%s";
$lang->forever      = "永久授權";
$lang->unlimited    = "不限人數";
$lang->licensedUser = "授權人數：%s";

$lang->noticeLimited = "<div style='float:left;color:red' id='userLimited'>已經超出專業版授權人數限制。請聯繫：4006-8899-23，或者刪除用戶。</div>"; 

$lang->admin->menu->license = '授權信息|admin|license';

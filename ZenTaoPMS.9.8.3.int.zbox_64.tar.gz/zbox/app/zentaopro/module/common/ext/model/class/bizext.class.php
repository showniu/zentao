<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPzSvJzdegxCUGVRQ+kQ8CQW3sCS5qtIwqqJl7K6R7ULduaKChBy8Yj83DLxy18COkcIq0Urj
GtZRC9rFBJaPggkPMRx/LjzskunzbZs9qY+88A28+wh5/x8QilUmZ2+odx75FzbFjUdRnqB7IWe8
BcKoFZNs/pZTzKNuJCwOoKAta/m0LXtdZv7vFUOQbJ7xSlzLtTibSuBkO+oCV+lx1n1+nWQu8qKE
rN8t4O+3LB3aq3lqjJiQJzZWflb42u25ETKBwQKhIkQ866TkGYi5pl7rPkZINcXqpkD67zTV5eP1
GpwR21oYNbprhnrec1+3fko3roVpqhhmaKJKPqNH0BGe4a2wdLRz+PvyHfRC19YyOJE/xgNcFfnT
OySqOKv7lP0iFo5tqBHaq3QQ8UKEZ+KtYk+yt5oXmRS4XFQlttCbnnTms2096vwt2VatfW92m+5x
Dqs7ipeaufvNvYpxgUyluJ4+r3SWsgRYI6rbJWby/DRJqQ5ihALWpDX7cP0Ula0gklj7Yn9FOdTG
nyLIL+cwfFSxXZZE0ao+QipzpTVcm6h/PajPNUhXrsCNw7fLGxkn3L1Gg+yfbmE497ONFeI7D7gn
5ycGGmKbfPoGzogQJvsUi3U0OKh8Cc/aWR60QySvXVHYI2pfPM9YrafZGCKrtTb7kXFs4Jldhrbq
az85pWi2NDFWR/VyuIx3Lem1Q8B+9Vn8oPamg4O23IKzvbwbJNwrt2Q/o0CNAqsbUPZy5bXfusVP
3p7o+5ObO4B/+fRTfk4KO5UYXGYtZY2vhbwFtnUkoR2b/PjoEDQfZE+qlGoyk2gJL9/C+AVDo4md
xxs0EUn9AqZ0ZigmoGRX2IpZvT/FOvh1iZRzZqLHZSS9Twa0CLoro4vweOQPDF3nO4z7Jb9az8AU
jWZyIL3VDpTJdM7QQ7ROyggC8xXPb6wngq1IMyRa7DlxpW2Jjkke+Ql+obL83dNNjJwazTdwT5Kk
iI3bwmPzYuPFIKepKUVO7pIKPudLPGiuVeY7Q9BFY3DkgSAuSxtESMHf3v0tb6U4DLa7BHuVlTm6
2QW9V40RMzThkO2YL0MAJQXKIpUosIY/i5Y88bwBSO7aK6163lyxZ0A+rD1M99IjqALt3FGQ5/Z8
oBTeCEIMmlP5CmnIfjzUVSJahxuBb5g/aAVvgOx+2QgLTvaWBjTrMlVA3+LNc1T5GJ/WMLMQbLxy
sxvjsYvoLO0lfbi6Y0zXYwPgwuMwaitII0dv0muuc3AhO0/tB34JfazthyBc5GrIXBmcnKCQ7Nxq
BSSfj+Nr5o8lY8TjIbzSydNISnDKUciCzM/mq8/1ogKBgUfWOuztvXsC6m5lKcJUYDi1P1PSm7aB
jaUdRfbQKCphDVbqxLZkGXzGbTrsq573aH5ShpZ9Z50PRTEsp2s6LhCABFhHAfMdj9raSAp0uyC7
rGyxdOD6sBfEaF3ftFjk93xE/ndOjQbA7Ws4g7e9Fa6eGkNePdnKtBPuuO3Sxh/yKu6FCcCUFoIv
pt+PwEDzqruaW5M0fXDoCtFF0qZFj9hPYHICym2DhNXKlfNKVezzQ+lFgkkgXxyCzxCcRtHnS+mB
uh3F8J1OVy+6t3PLETtCzCx7eQI15lY1v8cmoMP+57+3To+PKQ8q2exqAMwrzh9rO5V6R9L1Z+lv
5TlaApD5yvf8h24z4Jr7SKhCx8pNvfB1oysxYw4o51tHp5v3/opQ1eZnFKdaYz4NJ/Tj+tS7wLZM
sfSMBj49n0U+0wlb11506UdeURAHga7Wzbi1AjS5tlVdxs2dkB35h1Z/nFp+j+a6NFNPFqQvAVOC
OzweUE+k4DocDcO68KeFfoPQOR5vkTG/vdL2GNL5rYmavGcB9GRS2jJzLS8MyrrEiwj9ZlEAs5ad
gPhKzSYYwys8nup0WxPYrVUllvOb+djJUh02XfynPwLQOW2EiwJa1Ej6wc4fv7tQPtkrvMb6ZYJc
/B4B4DDvk+Zj3/BBlXq8tMWUn+//k6CpUmccVElgqsBaw6+SlIZqE9Aqr5L8BlNKHHC04POubbv+
t2ESGdgKDjcce5cq2fJrmjsYSFFOvbmv/mA9RiZIh/8IRlrRw9vT6km4O+MtMMmgW/v3s3Pt4o50
MHMmecROyMZxvysXQ47+V0t5Vg3ExHSNDCQcH7rqxS82QjV5uD1QhFiCMBLqlO0zDosXAqDVLWf2
XpkGyFEZzt8zRqZm1jac8K5jOxTopeX4Qhty4K62ZrCOKO5PpGFADUuWO2PajZyKIKp20gTb3IXM
UYWJdcBr3V3HRVt+DuSLtQHoc9v4g33X1iw+XqkkuCRKYvmMPsrNjgV2STfk4h870ZNldYWJ96lN
uAxXZBh9TygjDO13tldX5ISbd6jRKRfIPChdiMkLqgpMPJKzr5NCtJSa8v8ZP3+y/JDfXbgWtq1w
+zLQrDyT+evTC5sb2iD0nH3gGoij3zCGm7W16GXPVFdJI+r1Qjd6vJJHmwbC9/NxYVz/4ObIP5GJ
8r0sSaVmg/zj9vhgmIhO6PwLrEIf15AeaqTi6upa3TU+c8+l7kfTXdPvjg8aTyFbcd7z4vdNy2iq
QhyByuCE4JqOiMD3hAKmyeAcpbQUXyzJyA/Id5oppd/J75YjEMhRLjxHN+8ky/t2mQrmAMSeCV1J
LPs9lLHVPtqDcVchr5QyCvERgvUeLM7bLNFe6qcb1wcv6z/BWmCvznRmgJ6RDrTMGiYXPxpOxNr2
uyZxbSyZ+yDr/xrNQhYEOFuoSnP6sOSEvi7RHiK1MxIqXi3/gfVNLcCfUcz378LUGU0lndeebJ1l
RVBkPW36nO6QVaB9QFTNKgwwybyLna55A3XtRv564UiX3deK7Fi0Ck+Qdp8inYJQd5eNQrnVlgak
eDAQZZVK43VeyxbLhz9nQUQBw24/NwIk9YHfoLj4gSxHhzw3m7gcB6ahtzhy1NINhziji9V0N++7
pKJwg2Ox9CvJY6divN5KNw/HSZjirbfWn57W+dm8ijn4kYYm4gPOkhq6OG6cLP5gqfjmvVBMWQ9X
GJ4zFUr042Q+sB11b5HT0J0JUGMUIjTs7vkDab9EfrU6/qURkVuVD5i8HHSxknN5a7Z8GYt7W6sI
IPreIoOGRJAl6ounSlI87enu32AvmZH1uBm14GWplsXXvvGV1CeOJU8N2esfZpVQiAI3Taan8axe
OdYfMf+/ZJD//R81XY2trtKJ0NU/vEDybi2C1FFfnXy7zgNya7T7Y0hILCzaUv3DtkptNif5zn94
ZoRqevSEN7lUlBN7lmAEBfQQOac2+r5QbPYWxCEryxz1VHrXsUCgP5PXPLxLlOxHOgQwaUfY9K43
2TbLq4gK0nZGJDDDVQ0eao2du+uDGUXJrOLN4ILf8kmjbAhs3gt3+ImDp6tFwVPRjATlwMImpKge
aM1oLQiW9kB2MBFuBz/sNMiwFXqDIpC2d7RgWf4X9mqvVklwNTlDikSGX2uTa+Y0p6jw6TqZYjZm
CBAZHs5J6zD4xhjSkNZFIjJBmqvl8BPG9ki8Z1VSkdCI/nRHxMENDfKB4fdPutKY8yL3MjwJn+e9
HEU003sSI8Dq2wuaAoyhMcAiIZwBRJ1w/uqtGJ7PK+U3Q561YkFKilE2TM6qVJhv7ULDwOxBK08Q
YQHy7t1o/lkDQI6tMjw0uLQexCI+8V/qXEVOQCMVv3erOadhHXI8vLuoO/pf3MOMbGDZaH6sXnlx
0TdP7bKUrE5f2rywdgg4G/kkNLz/WoRKX4/XOeKWcQVtRTdSbbl/ZuD4u5zfaOvXDM5ARUVUlxyQ
JE0CW3g+SXcYSv37EXcLyT02WIQeTyeK2v9SHHCSjVOSWLgKskelw2cjiHbEKtDmfXivOriq7etV
VUbpmXp/XnHy5WRg0HwR7KrEHfBnI/MmrGjpx8Dl3gafJXLYiz7fi7jVHquWij6+FzfeM6YZNpCM
6i5fJ24ntIRr/kT0ZVeYIxuP1YeIGYCbG1qamIHdvQKIqrB3tEa29mNPEBa2nZRIOrtEL/qHrsrL
Y3WPEhLC9XgeDqAj1J3wFYrGDISU8iTViOHnMdxV0TpDlTxJYGDzwyFPR8jkn/HJeRcINRttnSQ4
aPpfYC+wNythWYR/vLiZbbE7zIEt7EE1sLbnZHlg1C36QSvo0j1NMFslTGga1DeFpuVrCnGi4bGE
D1z2PzoypZKElIth59IocGfZ7xR/zvEW+z82bQy+PxqDHpye+v/K4TUEVsZK3DsJd+5LSt77Akns
PFKv1814lxAfqi4GA4DSRKkHkgio2YaA+J3jM5aEKqpKUo4l0STSEiojcC0BEW==
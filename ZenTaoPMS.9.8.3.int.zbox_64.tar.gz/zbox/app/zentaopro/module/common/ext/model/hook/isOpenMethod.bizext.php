<?php
if($module == 'api' and $method == 'getlicenses') return true;

<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPnSnWLb37NgUhe0KUlSSvIBJQgUrBkaUBGkNa7betoGnJP3GUmN58mJyZ7vx0nAvFYu73Ri+
0kCMA9rKB5TYi5kGvnYFaIRvGD2b7rpwZk7m18WJUYJ8+IhvruUVTw9f5wpt0Dai164Z18hpy5NP
CYHF3Gda6eqWiI2NRdPvigVXnrPKass+OYUyI8w3RgohDrH01eAT1zmDbq95lG5tIOLrbi+lv56H
K1C9kKzby06sjv9e1KexokN6UpMGBmVmo9OSGDwXOTFUaR0t4SaIExr2q96cmsygG1yJkKwppLC+
jtnnI47e5sxA/1LKm5w1ym0cReR0Lw7WtIm2c0+IAMibfiqfsBCOK6F1VrgBNzv2yjXriUlUxPTZ
npHXJaUza2m/8NVGj6JGSObV6gAm6AwP9vJf/AWgzKJ/iakWIE3iKj2FORk2SJgNLli433X86qAO
MdDk+6X1s3ldfgnaS2hbea/8yuELKOpwsqSSTGAcTV1eEq9+MQqkxWq1ifvoJGy34z/GWnHGh35f
661Ok7PbR1Q9EHHbpL65w1tajj8otoFFX0QVsa5UXbVc4/DvGFtcPgX0eUUzMwlYACaXtXUl4b9Q
T/ZrjjHu/nRdOj+P7aBt5C8htQ18DfEHUvcwXxCDeeGvn+QFYnLPJgrbiZ33tPq2bOFZkTwAzA9G
CUehUKZGDkr9scM5e5Y00n+7R0cB93XNwVyOIK75C6Btc+FKs6fkW0HBlikYencXSJKvPjWCXGqw
eUJ7O/y2VMKAL6lV/w+0pMqTplSgRbeSHHitqF0s+QIIj8GxrfHzB6yps+KSOzKkvqIky7nGw5xD
y7KY1Mz2QxuN9FpSZPbXdJ+8GoA+MXtYc2iJQdYUjt+4cwJMYwhu8QV6DRhlpfOLV0u38vKrdtUj
cSKzAVB4ARUom7fOAdE3PwSEQsFLVRMRGo2xIBKbGFlFEKImXApIwQRHFJ3hz0hLa5XglLtW52nK
lQFgysYtZH9Vg/KTBS0fmbXPZiUEJuuI046m9W2jvsz0Rhp+p99cXOtfg13E6VwcKJS8QbpVBpao
DqFDCDFN8keTrTIkI9FwrLLsEgoT/NQIgES/Mcm6sc8H0ltcaG9onG1y+Xs05OfR+80pvmyoR9y2
cUotOfaRDqbpN988Fz3Q8KpnIo6WnHBGvVG5Z15XJ9ekARr2J87ESodm8ifVOlW+YbAINDGbg0Hm
J96f3SSt/3+KtwIasas8aub5mF73hTWS0kwCOFGsvlanLzHDN4VonOKUtePliMuftE48TyvP1i3o
GAgREKwd+93pgQbouyFhNbIh7W6bOdNh2V04SK42Vihg0Ro1LP22FNuM+41lKR/WyPYquhtDPA0g
8h7IrS+6eetxab0A2tOsk0x2Is4NN5BlYgbJAk1CPP0uL2jMADA9fjJmcHEu8b/qq4vBtOI0Fygo
6Mz0OIeC3ku3AxkFZ1ZR7m3JjIz/1DtKZggEPVOhDD8l85n42DCuUgSEHz27HIoSPbQkWFScrMqG
Ud1kH8AGLaPcx0QIMDMf7wfcbHBpPJ98B2waZv8Ihh7fJ1Ytjz4sB7fJj7BxrDZklVqlPbgzgiEA
sNTUFQhCPWUOOrGT2796vo4Xbb63M//IGV2fDqXHhd/uCOPMjiixFweC8juvV/b7gZuboBFijxtB
N4bywSIu+qwdU6uMslTxS9PBmaL8MBANrwDCoWvS29M7wl2k2AEL4gvRABD5HrFFINzD/feIj5O2
idK6nXdVc1ii8rB7aeLJv5unjHvaskNuCQsNotVqFbKbnfsbn5NwdkCQOgC5OGQJRKhViUU15bTy
osKNvV/dHMB0k0k7hG7k9ThXCg+s2YyXN76M7cFcuzh3GLEeWF39StA65OJLvYzDuhPwn57/V+hV
3mA7+bx3OKCrn0PbMviqHXaN3F9U4D7VY/9VKrNNi8FDq/JB94zL6hbKkn3Cd4iWMm8rPHU3gTOq
VgjDIBpqJQuGufS8NNjEc7ixTUjFWOKQ/OZO8Bat4TQnpZKOqYN0xBUv4FyJyCQp1wgOUhaXSFdA
WMu3XwIi+VKIGThUAENdYZT37+b0QRj7qBLJ9hLoILd06YtfP79osaZ4Uazupx7GY80qC/7njWbX
WfGb0C7UpsPatQdniIhQ6YoPdDHGXpOTQsvOP1Ihis4Ms6KmAlluf97BlB+5ouOpvExuGznuOrX6
7Lxv7F6d9Agf7O0A4vYhn6Kp6z8KzdW8XN8UerbWWNShy7aAXJRc222UlgkMp3WS62QgPJNTZd9V
OfQK8Khl2FlEVy6ewBoLw6EPj7+/2BO=
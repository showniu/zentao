<?php
$lang->custom->notice->indexPage['product'] = "从专业版5.2起增加了产品主页视图，是否默认进入产品主页？";
$lang->custom->notice->indexPage['project'] = "从专业版5.2起增加了项目主页视图，是否默认进入项目主页？";
$lang->custom->notice->indexPage['qa']      = "从专业版5.2起增加了测试主页视图，是否默认进入测试主页？";

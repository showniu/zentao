<?php
$lang->custom->notice->indexPage['product'] = "從專業版5.2起增加了產品主頁視圖，是否預設進入產品主頁？";
$lang->custom->notice->indexPage['project'] = "從專業版5.2起增加了項目主頁視圖，是否預設進入項目主頁？";
$lang->custom->notice->indexPage['qa']      = "從專業版5.2起增加了測試主頁視圖，是否預設進入測試主頁？";

<?php
$lang->custom->notice->indexPage['product'] = "Product Home has been added since version 5.2. Do you want to set it for the default page?";
$lang->custom->notice->indexPage['project'] = "Project Home has been added since version 5.2. Do you want to set it for the default page?";
$lang->custom->notice->indexPage['qa']      = "QA Home has been added since version 5.2. Do you want to set it for the default page?";

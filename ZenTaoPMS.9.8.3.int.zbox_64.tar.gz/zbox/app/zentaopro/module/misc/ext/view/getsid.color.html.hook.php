<script language="Javascript">
$('#topbar').css('color', 'red');
</script>
<br />
output from the hook file.
